# Reet Verma — AI/ML Portfolio

A responsive, single-page portfolio website using HTML, CSS, and JavaScript.

## Run locally
1. Extract `reet_verma_portfolio.zip`.
2. Open `index.html` in a modern browser.

No build tools, package installation, or server are required.

## Customize before publishing
- Confirm the correct degree title and education dates.
- Replace the shared profile link with the correct public LinkedIn or portfolio URL if needed.
- Add verified email, GitHub, project repositories, demos, screenshots, and accurate project tech stacks.
- Check all links and text before deploying.

## Deploy
You can upload `index.html` to GitHub Pages, Netlify, or another static hosting provider. The website is self-contained.


## Profile details included
- Admission year: 2023
- Current year: third year (2026)
- Graduation date: marked as to be confirmed
- LeetCode: https://leetcode.com/u/reetverma4/


## Contact and profile links
- Email: reetverma170@gmail.com
- LinkedIn: https://www.linkedin.com/in/reet-verma-b5084b314/
- Kaggle: https://www.kaggle.com/reetverma
- LeetCode: https://leetcode.com/u/reetvermaa/
- HackerEarth interview practice: https://www.hackerearth.com/practice/interviews/


## Animations included
- Animated neon AI orbit and floating tags in the hero section
- Soft glow pulse and gradient shimmer on buttons
- Scroll-reveal transitions for sections, skill cards, and project cards
- Hover lift effects on cards
- Respects the visitor's reduced-motion accessibility preference


## Profile links
- LinkedIn: https://www.linkedin.com/in/reet-verma-b5084b314/
- Kaggle: https://www.kaggle.com/reetverma
- LeetCode: https://leetcode.com/u/reetvermaa/
- HackerEarth practice page: https://www.hackerearth.com/practice/interviews/

## Animated design
The page includes neon orbit motion, floating hero tags, pulsing glow effects, hover transitions, and scroll-reveal effects. Reduced-motion preferences are respected.


## Confirmed contact details
- Email: reetverma170@gmail.com
- LeetCode: https://leetcode.com/u/reetverma4/
